const express = require('express');
const router = express.Router();
const { db } = require('../../handlers/db.js');

router.get('/instance/:id/subdomains', async (req, res) => {
    try {
        const allPluginData = await db.get('plugins') || [];
        const config = require('../../config.json');
        const { port, domain } = config;

        // Fetch user subdomains from the database
        const userId = req.user.id; // Assuming you have the user ID from the request
        const subdomains = await db.get(`subdomains-data:${userId}`) || []; // Fetch subdomains for the user

        // Render the EJS template with fetched data
        res.render('index', {
            req,
            port,
            user: req.user,
            name: await db.get('name') || 'Skyport',
            logo: await db.get('logo') || false,
            subdomain: subdomains, // Pass the fetched subdomains to the view
            addons: {
                plugins: allPluginData
            },
            errorMessage: 'Subdomain already exists.'
        });
    } catch (error) {
        console.error('Error fetching subdomains:', error);
        res.status(500).send('An error occurred while fetching subdomains');
    }
});

router.post('/instance/:id/subdomains/create', async (req, res) => {
    try {
        const userId = req.user.id; // Assuming you have the user ID from the request
        const { subdomain, serverIP } = req.body;

        // Fetch current subdomains
        const currentSubdomains = await db.get(`subdomains-data:${userId}`) || [];

        const config = require('../../config.json');
        const { port, domain } = config;
        const allPluginData = await db.get('plugins') || [];

        // Check if the subdomain already exists
        const exists = currentSubdomains.some(item => item.domain === subdomain);

        if (exists) {
            return res.render('index', {
                req,
                port,
                user: req.user,
                name: await db.get('name') || 'Skyport',
                logo: await db.get('logo') || false,
                subdomain: currentSubdomains,
                addons: {
                    plugins: allPluginData
                },
                errorMessage: 'Subdomain already exists.'
            });
        }
        

        // If it does not exist, add the new subdomain
        currentSubdomains.push({ domain: subdomain, ip: serverIP });
        await db.set(`subdomains-data:${userId}`, currentSubdomains);

        // Redirect or send a success response
        res.redirect(`/instance/${req.params.id}/subdomains`);
    } catch (error) {
        console.error('Error creating subdomain:', error);
        res.status(500).send('An error occurred while creating the subdomain');
    }
});

router.post('/instance/:id/subdomains/delete', async (req, res) => {
    try {
        const userId = req.user.id; // Assuming you have the user ID from the request
        const { subdomain } = req.body;

        // Fetch current subdomains
        let currentSubdomains = await db.get(`subdomains-data:${userId}`) || [];

        // Filter out the subdomain to delete
        currentSubdomains = currentSubdomains.filter((item) => item.domain !== subdomain);

        // Update the database
        await db.set(`subdomains-data:${userId}`, currentSubdomains);

        // Redirect or send a success response
        res.redirect(`/instance/${req.params.id}/subdomains`);
    } catch (error) {
        console.error('Error deleting subdomain:', error);
        res.status(500).send('An error occurred while deleting the subdomain');
    }
});


module.exports = router;
